# Strings Analytics


| Code | Language | Translated | Remaining |
|----|-------|-------|---|
| en | English [English] | 413 | 0 |
| id | Indonesia [Indonesia] | 389 | 24 |

### Note
- `NEED_TRANSLATION` says, "Translation is half remaining and in that place English Strings are placed, so Translation helper need to check file instead."

- If Strings are not present, Google Translation will be used to Translate them at time of Usage.
<br><br>
• Remaining Strings can be found [here](./remaining.csv) for easy sort out.