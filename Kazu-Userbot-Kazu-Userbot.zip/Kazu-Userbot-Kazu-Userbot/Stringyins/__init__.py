from .strings import get_languages, get_string, language
